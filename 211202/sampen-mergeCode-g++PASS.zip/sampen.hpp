#ifndef __AXI4_LAB_HPP
#define __AXI4_LAB_HPP


void sampen(float *,int, int&);
// void sampen(float *,int, float&);
#endif
