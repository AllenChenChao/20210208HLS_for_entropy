#include "sampen.hpp"
#include <string.h>
#include <math.h>
#include "bucket.hpp"
//#include <stdio.h>
//#include<iostream>
// #define Length  360

void sampen(float *in, int len, int& SampEn)
{
//#pragma HLS INTERFACE s_axilite port=return bundle=sqrt
//#pragma HLS INTERFACE s_axilite port=len bundle=sqrt
//#pragma HLS INTERFACE s_axilite port=SampEn bundle=sqrt
#pragma HLS INTERFACE m_axi depth=500 port=in offset=slave bundle=input
#pragma HLS INTERFACE s_axilite port=in
        len = 360;
        float buff[Length];
        // float r = 0.15;//float r = 21;
        float r = 0.2;
        
        int N = len;
        int m = 2;
        //int Samp;

        memcpy(buff, (const float*) in, len * sizeof(float));
    
        float X[Length-1];
        float Xmin = buff[0] + buff[1] ;
        float Xmax = buff[0] + buff[1] ;

        l1:for(int i = 0; i < len-1; i++){
                #pragma HLS loop_tripcount max=len-1
                X[i] = buff[i]+buff[i+1];
                if(X[i] > Xmax){ Xmax = X[i];}
                if(X[i] < Xmin){ Xmin = X[i];}
        }
        l2:for(int i = 0;i<len - 1;i++){
                #pragma HLS loop_tripcount max=len-1
                X[i] = X[i] - Xmin + 1;
        }
        // std::cout<<"Xmax:"<<ceil(Xmax)<<std::endl;
        Xmax = Xmax - Xmin + 1;
        int Nb = ceil(Xmax);
        // if (Nb>59) {Nb = 59;}
        if (Nb>299) {Nb = 299;}
        // std::cout<<"Xmax:"<<ceil(Xmax)<<std::endl;
        // int Nb = 10;



        int bucketCount;
        int bucketLocation;
        loopBuckAssignment:for(int i = 0; i < len - 1; i++){
                #pragma HLS loop_tripcount max=len-1
                // std::cout<<"i:"<<i<<std::endl;
                bucketCount = (int)ceil(X[i]/r)-1;
                // std::cout<<"bucketCount:"<<bucketCount<<std::endl;
                if(bucketCount > Nb-1){bucketCount = Nb-1;}
                bucket[bucketCount][0] = bucket[bucketCount][0] + 1;
                bucketLocation = bucket[bucketCount][0];
                bucket[bucketCount][bucketLocation] = i;
        }
        // std::cout<<"bucketCount:"<<bucket[9][1]<<std::endl;
        int count1 = 0;
        int count2 = 0;
        int tempiNum;
        int tempjNum;
        int templocationik;
        int templocationjg;
        int templocationik_2;
        int templocationjg_2;
        float tempComparsion1;
        float tempComparsion2;
        float tempComparsion3;
        loopBuckOutSearch: for(int i = 0; i < Nb; i ++){
                #pragma HLS pipeline off
                #pragma HLS loop_tripcount min=1 max=300
                int tempjLow = 0<i-2?i-2:0;
                int tempjHigh =i+3<Nb? i+3:Nb;
                // std::cout<<"i:"<<i<<std::endl;
                loopBuckInnerSearch:for(int j = tempjLow; j < tempjHigh; j ++){
                        #pragma HLS pipeline off
                        #pragma HLS loop_tripcount min=3 max=5
                        // if(j < i - 2){continue;} 
                        // if(j >= i+3 ){continue;}    
                        tempiNum = bucket[i][0];  
                        tempjNum = bucket[j][0];          
                        loopBuckOutMatch:for(int k = 0; k < tempiNum;k++){
                                #pragma HLS pipeline off
                                #pragma HLS loop_tripcount max=400
                                templocationik = bucket[i][k+1];                            
                                loopBuckInnerMatch:for(int g = 0; g < tempjNum ; g++){  
                                        #pragma HLS pipeline off
                                        #pragma HLS loop_tripcount max=500
                                        templocationjg = bucket[j][g+1];
                                        tempComparsion1 = abs(buff[templocationik] - buff[templocationjg]);
                                        tempComparsion2 = abs(buff[templocationik+1] - buff[templocationjg+1]);
                                        if( tempComparsion1 <= r && tempComparsion2 <= r){
                                                count1 = count1 + 1;
                                                // std::cout<<"match:"<<templocationik<<" "<<templocationjg<<std::endl;
                                                tempComparsion3 = abs(buff[templocationik+2] - buff[templocationjg+2]);
                                                templocationik_2 = templocationik+2;
                                                templocationjg_2 = templocationjg+2;
                                                if( templocationik_2 < len && templocationjg_2 < len &&  tempComparsion3 <= r) {
                                                        count2 = count2 + 1;
                                                }
                                        } 
                                }
                        }
                       
        	}
        }
        // std::cout<<"count1:"<<count1<<std::endl;
        // std::cout<<"count2:"<<count2<<std::endl;
        count1 = count1 - len + m -1;
        float B = (float)count1/((N-m+1)*(N-m));
        count2 = count2 - len + m ;
        // std::cout<<"count1:"<<count1<<std::endl;
        // std::cout<<"count2:"<<count2<<std::endl;
        float A = (float)count2/((N-m)*(N-m-1));
        if(A == 0){SampEn = 100000;}
        else {SampEn = int(1000*log(B/A));}
        if (SampEn < 0){SampEn = 0;}

}
