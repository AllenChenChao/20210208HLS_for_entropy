#include "sampen.hpp"
#include <string.h>
#include <math.h>
#include <stdio.h>
#include<iostream>
// #define Length  1000



void MergeSort(float a[Length], int length, int location_a[Length])
{

    float b[length];
    int location_b[length];
    int i = 0;
    int j = 0;
    int n  = length;
    int len_seg = 1;
    int Loop = ceil(log2(length));
    // int Loop = 10;
    float tmp = 0;
    int limit_i,limit_j;
    int flag = 0;
    Loop:for(int loop = 0; loop < Loop;loop++){
        // for 2^Loop #elements data,itera : 1,2,4,8 ... 2^Loop 
        Itera:for(int itera=0; itera < ceil((float)n/2/len_seg);itera++){ 
            #pragma HLS loop_tripcount min=1 max=length/2
            i = 2*itera*len_seg;
            j = (2*itera+1)*len_seg;
            limit_i = (2*itera+1)*len_seg;
            limit_j = 2*(itera+1)*len_seg;
            Merge:while( i < limit_i & i < length & j < limit_j & j < length ){
                #pragma HLS loop_tripcount min=1 max=length avg=length/2
                if(flag == 0){
                    if(a[i] < a[j]){
                        b[i+j-2*itera*len_seg-len_seg] = a[i];
                        location_b[i+j-2*itera*len_seg-len_seg] = location_a[i];
                        i = i + 1;
                    }
                    else{
                        b[i+j-2*itera*len_seg-len_seg] = a[j];
                        location_b[i+j-2*itera*len_seg-len_seg] = location_a[j];
                        j = j + 1;           
                    }
                }
                else{
                    if(b[i] < b[j]){
                        a[i+j-2*itera*len_seg-len_seg] = b[i];
                        location_a[i+j-2*itera*len_seg-len_seg] = location_b[i];
                        i = i + 1;
                    }else{
                        a[i+j-2*itera*len_seg-len_seg] = b[j];
                        location_a[i+j-2*itera*len_seg-len_seg] = location_b[j];
                        j = j + 1;           
                    }                    
                }
            }
            Merge1:while(i < limit_i & i < length){
                #pragma HLS loop_tripcount min=0 max=length avg=length/2
                if(flag == 0){
                    b[i+j-2*itera*len_seg-len_seg] = a[i];
                    location_b[i+j-2*itera*len_seg-len_seg] = location_a[i];
                    i = i + 1;          
                }else{
                    a[i+j-2*itera*len_seg-len_seg] = b[i];
                    location_a[i+j-2*itera*len_seg-len_seg] = location_b[i];
                    i = i + 1; 
                }        
            }
            Merge2:while(j < limit_j & j < length){
                #pragma HLS loop_tripcount min=0 max=length avg=length/2
                if(flag == 0){
                    b[i+j-2*itera*len_seg-len_seg] = a[j];
                    location_b[i+j-2*itera*len_seg-len_seg] = location_a[j];
                    j = j + 1;    
                }else{
                    a[i+j-2*itera*len_seg-len_seg] = b[j];
                    location_a[i+j-2*itera*len_seg-len_seg] = location_b[j];
                    j = j + 1; 
                }                
            }
            
      
        }
        if (flag == 0) flag = 1;
        else flag = 0;
        len_seg = 2 * len_seg;
    }
    
    for(i = 0; i < n ; ++i){
        if (Loop % 2 == 0){
            a[i] = a[i];
            location_a[i] = location_a[i];
        }else{
            a[i] = b[i];
            location_a[i] = location_b[i];
        }
    }  
  
    // std::cout<<"--"<<std::endl;
}


void sampen(float *in, int len, int& SampEn)
{
#pragma HLS INTERFACE s_axilite port=return bundle=sqrt
#pragma HLS INTERFACE s_axilite port=len bundle=sqrt
#pragma HLS INTERFACE s_axilite port=SampEn bundle=sqrt
#pragma HLS INTERFACE m_axi depth=1000 port=in offset=slave bundle=input
#pragma HLS INTERFACE s_axilite port=in

len = Length;
        // float buff[9] = {90, 60, 50, 95, 85, 70, 80, 110, 70};
        float buff[Length];
        float a[Length];
        int b[Length];
        // float r = 21;
        // float r = 0.15;
        float r = 0.2;
        
        int N = len;
        int m = 2;
        //int Samp;

        memcpy(buff, (const float*) in, len * sizeof(float));
     
        loop_init:for (int i = 0; i < len; i++){
                b[i] = i;
                a[i] = buff[i];
        }
        // BubbleSortTest(a, Length, b);
        MergeSort(a, Length, b);
        //
        int count1 = 0;
        int count2 = 0;
        int j;
        float limitIvalue;
        float difference2;
        float difference3;
        float condition;
        // ORIGINAL VERSION: SLOW
       /* loop1:for(int i = 0; i < len - 1; i ++){
				#pragma HLS loop_tripcount min=1 max=3600-1
                j = i+1;
                loopsearch:while(j < len && a[j]-a[i]<r){
                        #pragma HLS loop_tripcount min=1 max=3600-1
                        if(a[j]-a[i]<r && abs(buff[b[i]+1] - buff[b[j]+1])<r && (b[i] < len -1) && (b[j] < len - 1)){
                            count1 = count1+1;
                        }
                        if(a[j]-a[i]<r && abs(buff[b[i]+1] - buff[b[j]+1])<r && abs(buff[b[i]+2] - buff[b[j]+2])<r && (b[i] < len -2) && (b[j] < len - 2)){
                            count2 = count2+1;
                        }
                        j = j+1;
                }
        }*/
        //
        // NEW VERSION: 1.12x FASTER
       /* loop1:for(int i = 0; i < len - 1; i ++){
       				#pragma HLS loop_tripcount min=1 max=3600-1
                       j = i+1;
                       float a_i = a[i];
                       loopsearch:while(j < len && condition<r){
                    	   	   condition = a[j]-a_i;
                               #pragma HLS loop_tripcount min=1 max=3600-1
                               if(abs(buff[b[i]+1] - buff[b[j]+1])<r && (b[i] < len -1) && (b[j] < len - 1)){
                                   count1 = count1+1;
                               }
                               if(abs(buff[b[i]+1] - buff[b[j]+1])<r && abs(buff[b[i]+2] - buff[b[j]+2])<r && (b[i] < len -2) && (b[j] < len - 2)){
                                   count2 = count2+1;
                               }
                               j = j+1;
                       }
	   }*/

       /* // NEW VERSION: 1 clock cycle LESS IN THE ITERATION LATENCY THAN loopsearch
        loop1:for(int i = 0; i < len - 1; i ++){
       				#pragma HLS loop_tripcount min=1 max=3600-1
                       j = i+1;
                       float a_i = a[i];
                       float b_i = b[i];
                       float b_1_1 = buff[b[i]+1];
                       float b_1_2 = buff[b[i]+2];
                       loopsearch:while(j < len && condition<r){
                    	   	   condition = a[j]-a_i;
                               #pragma HLS loop_tripcount min=1 max=3600-1
                               if(abs(b_1_1 - buff[b[j]+1])<r && (b_i < len -1) && (b[j] < len - 1)){
                                   count1 = count1+1;
                               }
                               if(abs(b_1_1 - buff[b[j]+1])<r && abs(b_1_2 - buff[b[j]+2])<r && (b_i < len -2) && (b[j] < len - 2)){
                                   count2 = count2+1;
                               }
                               j = j+1;
                       }
	   }*/

        /*// NEW VERSION: 8.9x FASTER?
                loop1:for(int i = 0; i < len - 1; i ++){
               				#pragma HLS loop_tripcount min=1 max=3600-1
                               j = i+1;
                               float a_i = a[i];
                               float b_i = b[i];
                               float b_1_1 = buff[b[i]+1];
                               float b_1_2 = buff[b[i]+2];
                               loopsearch:
							   for (j = i+1 ; j < len; j++ ){
									  #pragma HLS loop_tripcount min=1 max=3600-1
                                       if(a[j]-a_i<r && abs(b_1_1 - buff[b[j]+1])<r && (b_i < len -1) && (b[j] < len - 1)){
                                           count1 = count1+1;
                                       }
                                       if(a[j]-a_i<r && abs(b_1_1 - buff[b[j]+1])<r && abs(b_1_2 - buff[b[j]+2])<r && (b_i < len -2) && (b[j] < len - 2)){
                                           count2 = count2+1;
                                     }
                               }
        	   }*/

                // NEW VERSION: 8.9x FASTER? Loopsearch loop does not always iterate until j = len
                        loop1:for(int i = 0; i < len - 1; i ++){
                       				#pragma HLS loop_tripcount min=1 max=len-1
                                       j = i+1;
                                       float a_i = a[i];
                                       float b_i = b[i];
                                       float b_1_1 = buff[b[i]+1];
                                       float b_1_2 = buff[b[i]+2];
                                       loopsearch:
        							   for (j = i+1 ; j < len; j++ ){
        									  #pragma HLS loop_tripcount min=1 max=len-1
                                               if(a[j]-a_i<r && abs(b_1_1 - buff[b[j]+1])<r && (b_i < len -1) && (b[j] < len - 1)){
                                                   count1 = count1+1;
                                               }
                                               if(a[j]-a_i<r && abs(b_1_1 - buff[b[j]+1])<r && abs(b_1_2 - buff[b[j]+2])<r && (b_i < len -2) && (b[j] < len - 2)){
                                                   count2 = count2+1;
                                             }
                                               // It is better to do not use this condition since then
                                               // an II = 1 is achieved. Otherwise, II = 9
                                               // Basically, certain % of cc are lost in entering/exiting the loop.
                                               // Check impact for large input data lengthks
                                              /*if(a[j]-a_i<r)
                                            	   j = len; // Alternative to break;
                                            	   */

                                       }
                	   }

        // count1 = count1 - len + m - 1;
        float B = (float)count1/((N-m+1)*(N-m));
        // count2 = count2 - len + m;
        float A = (float)count2/((N-m)*(N-m-1));
        if(A == 0){SampEn = 100000;}
        else {SampEn = int(1000*log(B/A));}
        if (SampEn < 0){SampEn = 0;}
}
