#include "sampen.hpp"
#include <string.h>
#include <math.h>
#include <stdio.h>
#include<iostream>
// #define Length  1000



void MergeSort(float a[Length], int length, int location_a[Length])
{

    float b[length];
    int location_b[length];
    int i = 0;
    int j = 0;
    int n  = length;
    int len_seg = 1;
    int Loop = ceil(log2(length));
    // int Loop = 10;
    float tmp = 0;
    int limit_i,limit_j;
    int flag = 0;
    Loop:for(int loop = 0; loop < Loop;loop++){
        // for 2^Loop #elements data,itera : 1,2,4,8 ... 2^Loop 
        Itera:for(int itera=0; itera < ceil((float)n/2/len_seg);itera++){ 
            #pragma HLS loop_tripcount min=1 max=length/2
            i = 2*itera*len_seg;
            j = (2*itera+1)*len_seg;
            limit_i = (2*itera+1)*len_seg;
            limit_j = 2*(itera+1)*len_seg;
            Merge:while( i < limit_i & i < length & j < limit_j & j < length ){
                #pragma HLS loop_tripcount min=1 max=length avg=length/2
                if(flag == 0){
                    if(a[i] < a[j]){
                        b[i+j-2*itera*len_seg-len_seg] = a[i];
                        location_b[i+j-2*itera*len_seg-len_seg] = location_a[i];
                        i = i + 1;
                    }
                    else{
                        b[i+j-2*itera*len_seg-len_seg] = a[j];
                        location_b[i+j-2*itera*len_seg-len_seg] = location_a[j];
                        j = j + 1;           
                    }
                }
                else{
                    if(b[i] < b[j]){
                        a[i+j-2*itera*len_seg-len_seg] = b[i];
                        location_a[i+j-2*itera*len_seg-len_seg] = location_b[i];
                        i = i + 1;
                    }else{
                        a[i+j-2*itera*len_seg-len_seg] = b[j];
                        location_a[i+j-2*itera*len_seg-len_seg] = location_b[j];
                        j = j + 1;           
                    }                    
                }
            }
            Merge1:while(i < limit_i & i < length){
                #pragma HLS loop_tripcount min=0 max=length avg=length/2
                if(flag == 0){
                    b[i+j-2*itera*len_seg-len_seg] = a[i];
                    location_b[i+j-2*itera*len_seg-len_seg] = location_a[i];
                    i = i + 1;          
                }else{
                    a[i+j-2*itera*len_seg-len_seg] = b[i];
                    location_a[i+j-2*itera*len_seg-len_seg] = location_b[i];
                    i = i + 1; 
                }        
            }
            Merge2:while(j < limit_j & j < length){
                #pragma HLS loop_tripcount min=0 max=length avg=length/2
                if(flag == 0){
                    b[i+j-2*itera*len_seg-len_seg] = a[j];
                    location_b[i+j-2*itera*len_seg-len_seg] = location_a[j];
                    j = j + 1;    
                }else{
                    a[i+j-2*itera*len_seg-len_seg] = b[j];
                    location_a[i+j-2*itera*len_seg-len_seg] = location_b[j];
                    j = j + 1; 
                }                
            }
            
      
        }
        if (flag == 0) flag = 1;
        else flag = 0;
        len_seg = 2 * len_seg;
    }
    
    for(i = 0; i < n ; ++i){
        if (Loop % 2 == 0){
            a[i] = a[i];
            location_a[i] = location_a[i];
        }else{
            a[i] = b[i];
            location_a[i] = location_b[i];
        }
    }  
  
    // std::cout<<"--"<<std::endl;
}


void sampen(float *in, int len, int& SampEn)
{
#pragma HLS INTERFACE s_axilite port=return bundle=sqrt
#pragma HLS INTERFACE s_axilite port=len bundle=sqrt
#pragma HLS INTERFACE s_axilite port=SampEn bundle=sqrt
#pragma HLS INTERFACE m_axi depth=1000 port=in offset=slave bundle=input
#pragma HLS INTERFACE s_axilite port=in

len = Length;
        // float buff[9] = {90, 60, 50, 95, 85, 70, 80, 110, 70};
        float buff[Length+2];
        // #pragma HLS ARRAY_PARTITION variable=buff cycle factor=4 dim=1
        float a[Length];
        float a2[Length];
        float a3[Length];
        float ca[Length];
        float ca2[Length];
        float ca3[Length];
        int C1[Length];
        int C2[Length];
        int b[Length];
        // float r = 21;
        // float r = 0.15;
        float r = 0.2;
        
        int N = len;
        int m = 2;
        //int Samp;

        memcpy(buff, (const float*) in, len * sizeof(float));
        buff[Length] = buff[0];
        buff[Length+1] = buff[1];
        for (int i = 0; i < len; i++){
                b[i] = i;
                a[i] = buff[i];
        }
        // BubbleSortTest(a, Length, b);
        MergeSort(a, Length, b);
        //
        // int hole2cd;
        // int hole3rd;
        loop_threeslipe:for(int i = 0; i < len - 1; i ++){
             ca[i] = a[i];
             a2[i] = buff[b[i]+1];
             ca2[i] = buff[b[i]+1];
             a3[i] = buff[b[i]+2];
             ca3[i] = buff[b[i]+2];
        }
        int count1 = 0;
        int count2 = 0;
        int j;
        float limitIvalue;
        float difference2;
        float difference3;

        #pragma HLS DATAFLOW
        loop1:for(int i = 0; i < len/2; i ++){
                j = i+1;  
                loopsearch:while(j < len && ca[j]-a[i]<r){
                        #pragma HLS loop_tripcount min=0 max=len-1
                        #pragma HLS PIPELINE
                        if(abs(a[i]-ca[j])<r && abs(a2[i]-ca2[j])<r){
                            C1[i] = C1[i] + 1;
//                        	count1 = count1+1;
                        }
                        if(abs(a[i]-ca[j])<r && abs(a2[i]-ca2[j])<r && abs(a3[i]-ca3[j])<r){
                        	C2[i] = C2[i] + 1;
//                        	count2 = count2+1;
                        }
                        j = j+1;
                }     
        }

        loop1:for(int i = len/2; i < len - 1; i ++){
                j = i+1;  
                loopsearch:while(j < len && ca[j]-a[i]<r){
                        #pragma HLS loop_tripcount min=0 max=len-1
                        #pragma HLS PIPELINE
                        if(abs(a[i]-ca[j])<r && abs(a2[i]-ca2[j])<r){
                            C1[i] = C1[i] + 1;
//                        	count1 = count1+1;
                        }
                        if(abs(a[i]-ca[j])<r && abs(a2[i]-ca2[j])<r && abs(a3[i]-ca3[j])<r){
                        	C2[i] = C2[i] + 1;
//                        	count2 = count2+1;
                        }
                        j = j+1;
                }     
        }        


        Count:for(int i = 0; i < len - 1; i ++){
        	count1 = count1 + C1[i];
        	count2 = count2 + C2[i];
        }


        /*
        loop1:for(int i = 0; i < len - 1; i ++){
                j = i+1;  
                loopsearch:while(j < len && a[j]-a[i]<r){
                        #pragma HLS loop_tripcount min=0 max=len-1
                        // #pragma HLS UNROLL
                        if(abs(buff[b[i]] - buff[b[j]])<r && abs(buff[b[i]+1] - buff[b[j]+1])<r && (b[i] < len -1) && (b[j] < len - 1)){
                            count1 = count1+1;
                        }
                        if(abs(buff[b[i]] - buff[b[j]])<r && abs(buff[b[i]+1] - buff[b[j]+1])<r && abs(buff[b[i]+2] - buff[b[j]+2])<r && (b[i] < len -2) && (b[j] < len - 2)){
                            count2 = count2+1;
                        }
                        j = j+1;
                }
        }
        */
        //

        // count1 = count1 - len + m - 1;
        float B = (float)count1/((N-m+1)*(N-m));
        // count2 = count2 - len + m;
        float A = (float)count2/((N-m)*(N-m-1));
        if(A == 0){SampEn = 100000;}
        else {SampEn = int(1000*log(B/A));}
        if (SampEn < 0){SampEn = 0;}
}
