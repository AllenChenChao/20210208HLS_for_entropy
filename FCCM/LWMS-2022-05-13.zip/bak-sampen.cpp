#include "sampen.hpp"
#include <string.h>
#include <math.h>
#include <stdio.h>
#include<iostream>
#include "time.h"
// #define Length  1000



void MergeSort(float a[Length], int length, int location_a[Length])
{

    float b[length];
    int location_b[length];
    int i = 0;
    int j = 0;
    int n  = length;
    int len_seg = 1;
    int Loop = ceil(log2(length));
    // int Loop = 10;
    float tmp = 0;
    int limit_i,limit_j;
    int flag = 0;
    Loop:for(int loop = 0; loop < Loop;loop++){
        // for 2^Loop #elements data,itera : 1,2,4,8 ... 2^Loop 
        Itera:for(int itera=0; itera < ceil((float)n/2/len_seg);itera++){ 
            #pragma HLS loop_tripcount min=1 max=length/2
            i = 2*itera*len_seg;
            j = (2*itera+1)*len_seg;
            limit_i = (2*itera+1)*len_seg;
            limit_j = 2*(itera+1)*len_seg;
            Merge:while( i < limit_i & i < length & j < limit_j & j < length ){
                #pragma HLS loop_tripcount min=1 max=length avg=length/2
                if(flag == 0){
                    if(a[i] < a[j]){
                        b[i+j-2*itera*len_seg-len_seg] = a[i];
                        location_b[i+j-2*itera*len_seg-len_seg] = location_a[i];
                        i = i + 1;
                    }
                    else{
                        b[i+j-2*itera*len_seg-len_seg] = a[j];
                        location_b[i+j-2*itera*len_seg-len_seg] = location_a[j];
                        j = j + 1;           
                    }
                }
                else{
                    if(b[i] < b[j]){
                        a[i+j-2*itera*len_seg-len_seg] = b[i];
                        location_a[i+j-2*itera*len_seg-len_seg] = location_b[i];
                        i = i + 1;
                    }else{
                        a[i+j-2*itera*len_seg-len_seg] = b[j];
                        location_a[i+j-2*itera*len_seg-len_seg] = location_b[j];
                        j = j + 1;           
                    }                    
                }
            }
            Merge1:while(i < limit_i & i < length){
                #pragma HLS loop_tripcount min=0 max=length avg=length/2
                if(flag == 0){
                    b[i+j-2*itera*len_seg-len_seg] = a[i];
                    location_b[i+j-2*itera*len_seg-len_seg] = location_a[i];
                    i = i + 1;          
                }else{
                    a[i+j-2*itera*len_seg-len_seg] = b[i];
                    location_a[i+j-2*itera*len_seg-len_seg] = location_b[i];
                    i = i + 1; 
                }        
            }
            Merge2:while(j < limit_j & j < length){
                #pragma HLS loop_tripcount min=0 max=length avg=length/2
                if(flag == 0){
                    b[i+j-2*itera*len_seg-len_seg] = a[j];
                    location_b[i+j-2*itera*len_seg-len_seg] = location_a[j];
                    j = j + 1;    
                }else{
                    a[i+j-2*itera*len_seg-len_seg] = b[j];
                    location_a[i+j-2*itera*len_seg-len_seg] = location_b[j];
                    j = j + 1; 
                }                
            }
            
      
        }
        if (flag == 0) flag = 1;
        else flag = 0;
        len_seg = 2 * len_seg;
    }
    
    for(i = 0; i < n ; ++i){
        if (Loop % 2 == 0){
            a[i] = a[i];
            location_a[i] = location_a[i];
        }else{
            a[i] = b[i];
            location_a[i] = location_b[i];
        }
    }  
  
    // std::cout<<"--"<<std::endl;
}


void sampen(float *in, int len, int& SampEn)
{
#pragma HLS INTERFACE s_axilite port=return bundle=sqrt
#pragma HLS INTERFACE s_axilite port=len bundle=sqrt
#pragma HLS INTERFACE s_axilite port=SampEn bundle=sqrt
#pragma HLS INTERFACE m_axi depth=1000 port=in offset=slave bundle=input
#pragma HLS INTERFACE s_axilite port=in

len = Length;
        // float buff[9] = {90, 60, 50, 95, 85, 70, 80, 110, 70};
        float buff[Length];
        float a[Length];
        int b[Length];
        // float r = 21;
        // float r = 0.15;
        float r = 0.2;
        
        int N = len;
        int m = 2;
        //int Samp;

        memcpy(buff, (const float*) in, len * sizeof(float));
     
        for (int i = 0; i < len; i++){
                b[i] = i;
                a[i] = buff[i];
        }
        // BubbleSortTest(a, Length, b);
        MergeSort(a, Length, b);
        //
        float D[2][Length];
        Copy:for(int i = 0; i < len - 1; i ++){
            D[0][i] = a[i];
            D[1][i] = a[i];
        }
        int Count1;
        int Count2;
        int count1[2] = {0,0};
        int count2[2] = {0,0};
        int j[2];
        float limitIvalue[2];
        float difference2[2];
        float difference3[2];
        int MAXwidth;
        if(Length == 360){
            MAXwidth = 289;
        }
        else if (Length == 1800)
        {
            MAXwidth = 1412;
        }
        else if (Length == 3600)
        {
            MAXwidth = 3008;
        }
        else if (Length == 7200)
        {
            MAXwidth = 5470;
        }
        else if (Length == 10800)
        {
            MAXwidth = 7001;
        }
        else if (Length == 21600)
        {
            MAXwidth = 14344;
        }
        else if (Length == 54000)
        {
            MAXwidth = 37896;
        }
        else if (Length == 108000)
        {
            MAXwidth = 57576;
        }
        else {
            MAXwidth = 57576;
        }
        
        std::cout<<" TEST:"<<TEST<<std::endl;
        {
        need_dataflow:
        #pragma HLS DATAFLOW
        loop1_1:for(int i = 0; i < len/2 ; i ++){
                j[0] = i+1;  
                loopsearch_1:while(j[0] < len){
                        #pragma HLS loop_tripcount min=0 max=len-1
                        limitIvalue[0] = D[0][i] + r;
                        if( limitIvalue[0] >= D[0][j[0]]){
                                difference2[0]  = abs(buff[b[i]+1] - buff[b[j[0]]+1]);
                                if( (b[i] < len -1)  && (b[j[0]] < len - 1) && (difference2[0] <= r) ){
                                        count1[0] = count1[0] + 1;
                                        difference3[0] = abs(buff[b[i]+2] - buff[b[j[0]]+2]);
                                        if ( b[i] < len - 2 && b[j[0]] < len - 2 && difference3[0] <= r ){
                                                count2[0] = count2[0] + 1;
                                        }
                                }
                        }
                        else {j[0] = len - 1;}
                        j[0] = j[0]+1;
                }
        }
            loop1_2:for(int i = len/2; i < len - 1; i ++){
                j[1] = i+1;  
                loopsearch_2:while(j[1] < len){
                        #pragma HLS loop_tripcount min=0 max=len-1
                        limitIvalue[1] = D[1][i] + r;
                        if( limitIvalue[1] >= D[1][j[1]]){
                                difference2[1]  = abs(buff[b[i]+1] - buff[b[j[1]]+1]);
                                if( (b[i] < len -1)  && (b[j[1]] < len - 1) && (difference2[1] <= r) ){
                                        count1[1] = count1[1] + 1;
                                        difference3[1] = abs(buff[b[i]+2] - buff[b[j[1]]+2]);
                                        if ( b[i] < len - 2 && b[j[1]] < len - 2 && difference3[1] <= r ){
                                                count2[1] = count2[1] + 1;
                                        }
                                }
                        }
                        else {j[1] = len - 1;}
                        j[1] = j[1]+1;
                }
        }
        }
        
        Count1 = count1[0] + count1[1];
        Count2 = count2[0] + count2[1];
        // count1 = count1 - len + m - 1;
        float B = (float)Count1/((N-m+1)*(N-m));
        // count2 = count2 - len + m;
        float A = (float)Count2/((N-m)*(N-m-1));
        if(A == 0){SampEn = 100000;}
        else {SampEn = int(1000*log(B/A));}
        if (SampEn < 0){SampEn = 0;}
}
